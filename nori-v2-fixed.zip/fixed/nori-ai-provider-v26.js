/* NORI AI PROVIDER STATUS V26 — stable API contract, no keys in client. */
(function(g){'use strict';
  async function request(){if(g.NoriApiV1)return g.NoriApiV1.request({mode:'provider_status'});throw new Error('Nori API client unavailable');}
  function summarize(data){const ps=(data&&data.providers)||[];return {configured:ps.filter(p=>p.configured).map(p=>p.provider),usable:ps.filter(p=>p.usable).map(p=>p.provider),cooling:ps.filter(p=>p.configured&&!p.usable).map(p=>p.provider)}}
  async function capabilities(){return g.NoriApiV1?g.NoriApiV1.capabilities():null}
  g.NoriAIProviderV26={status:request,summarize:summarize,capabilities:capabilities,version:'26'};g.NoriAIProviderV25=g.NoriAIProviderV26;
})(window);
