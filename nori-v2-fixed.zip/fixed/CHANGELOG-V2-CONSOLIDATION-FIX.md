# Nori — V2 Consolidation & Provider Fix

## V2.1 — Brain: smarter + faster (no behavior-risking changes)

I read through the whole provider chain before touching anything. It's
already well-built — response caching, circuit breakers with backoff,
bounded retries only for transient errors, a local-first fast path for
trivial messages, and cross-model verification that's *already* skipped
for simple queries. I deliberately did **not** touch the timeout/retry
machinery — adding a "race the top providers" hedge would have risked
falsely marking a healthy-but-slow provider as failed and pushing it into
cooldown, which is exactly the kind of subtle regression to avoid. Instead:

- **Fixed a real accuracy bug in the fast path.** `localBrainFallback()`
  was reused for two different situations: the genuine "every AI provider
  is down" case, and a deliberate shortcut that skips the AI call entirely
  for trivial messages (greetings, simple math, quick data lookups) because
  a deterministic answer is already correct and instant. Both cases said
  things like *"my hosted reasoning is offline right now"* — which was
  **false** in the fast-path case, since the AI was working fine and it was
  just being efficient. Split the wording so the fast path sounds like Nori
  working normally, and the real offline case still sounds honest about
  being degraded. Zero effect on when either path is taken — wording only.
- **Longer cache lifetime for answers that don't change.** Simple,
  context-free "fast" answers (definitions, quick facts) now cache for 20
  minutes instead of 90 seconds — repeat/near-duplicate questions come back
  instantly with no provider call. Web-search and reasoning-mode answers
  keep the original short 90-second TTL, since those are the ones most
  likely to go stale. The existing strict cache-eligibility rules (no
  history, no state, no web search, etc.) are unchanged — this only affects
  *how long* an already-safe-to-cache answer stays cached.

This pass fixed the root causes behind "AI doesn't work," missing read-aloud,
the lost 25-source research brain, and the provider problem. It did **not**
rewrite the app — it reconnected pieces that already existed on disk but had
drifted apart.

## What was actually broken

1. **Chat never reached your real AI backend.**
   `nori-modern-integration-v2.js` called a hardcoded Supabase Edge Function
   URL (`.../functions/v1/nori-brain`) that isn't part of this project and
   was never deployed. When that failed, `kage-modern.js` silently swapped in
   fake regex-matched text instead of showing an error — so it *looked* like
   a broken AI instead of a wiring bug.
2. **58 of 117 JS modules were never loaded by `index.html`**, including:
   - `nori-voice-v28.js` — the real text-to-speech engine (this is your
     read-aloud + speed control; it already existed, it just wasn't included
     on the page)
   - `nori-tier4.js` — the research/web-search/document-RAG/workflow brain
     (this is your "25 sources + deep thinking" — same story, on disk but
     unloaded)
   - `nori-update-v31.js` — the update coordinator
3. **Four different brain versions were loaded at once**
   (`nori-brain-v10/v12/v13/v14.js`), overwriting each other's globals. Kept
   only v14 (it's self-contained and "V12-compatible" per its own header).
4. **Stale hardcoded model IDs** (`gpt-6-luna`, `gpt-6-sol`,
   `gemini-3.8-flash`) don't match any current provider model. Updated to
   `gpt-5.6-luna`, `gpt-5.6-sol`, and `gemini-flash-latest` (an
   auto-updating alias, so Gemini won't go stale again the same way).
   Anthropic's model IDs were already correct.

## What changed, file by file

- `index.html` — removed v10/v12/v13 brain scripts; added back voice v28,
  tier4, update-v31, and a new `nori-auto-update-check.js`.
- `nori-modern-integration-v2.js` — `askNori()` now goes through
  `window.NoriApiV1` (which already correctly targets `/api/nori` and
  attaches the real auth token), instead of the dead Supabase URL.
- `kage-modern.js` —
  - `sendChat()` routes research/handbook/workflow-shaped questions to the
    restored tier4 brain; on real failure it tells you *why* instead of
    faking a reply; deterministic local answers (your actual recorded score,
    assignment count, etc.) still work without any AI provider.
  - Added a 🔊 read-aloud button on every Nori reply, an auto-speak toggle,
    and a speed slider — all wired to the restored `NoriVoiceV28`.
  - Home/Recover/Tracker stat cards are now clickable and route to the
    matching real screen (Overall Result → Tracker, Recovery → Recover,
    Merit → Awards, Focus → Timer, etc.), the same way the Library tile
    already worked.
- `api/brain.js`, `api/provider-status.js`, `api/verify-photo.js` — model ID
  fixes above.
- `nori-auto-update-check.js` (new) — polls the existing `/api/nori`
  contract/version response and shows a refresh banner when it changes.
  No external manifest host required.
- `capacitor.config.json`, `.github/workflows/build-apk.yml`,
  `package.json` — a Capacitor + GitHub Actions scaffold for building the
  APK on GitHub, since none existed in this project before.

## What you still need to do — I could not verify these here

- **Set the four provider API keys** as environment variables on whatever
  host runs the `api/` folder (Vercel or similar): `GEMINI_API_KEY`,
  `OPENAI_API_KEY`, `OPENAI_BACKUP_API_KEY` (optional), `GROQ_API_KEY`,
  `ANTHROPIC_API_KEY`. Also `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`
  — every mode in `api/brain.js` requires a signed-in Supabase user
  (see `requireUser` in `api/_security.js`), so sign-in has to work for AI
  chat to respond at all. See `SUPABASE_SETUP.md`.
- **The GitHub Actions workflow is untested** — I have no network or Android
  SDK access in this environment, so I could not run a real build. It's a
  standard Capacitor + Gradle scaffold; expect to debug the first run.
- **Confirm you actually want the Supabase admission-gate** (sign up →
  pending → approved) in front of every feature, since it's currently the
  reason AI, and everything else, is unreachable until an account is
  approved. If you want a simpler "just works, no login" version for
  testing, that's a bigger change I'd want to scope separately.
- I deliberately did **not** re-add the other ~50 unused files (old avatar
  versions, admin consoles, `nori-meet.js`, `nori-phase-app.js`, etc.) — I
  couldn't verify they don't conflict with the current `kage-modern.js`
  front end without a real browser to test in. If you want any of those
  features back, tell me which one and I'll check it properly before wiring
  it in.
