# KAGE Elite Academy — Modern Command Center v2

A refined monochrome KAGE/Nori prototype with a more modern editorial interface while preserving the Elite Academy visual language.

## Included
- 3-second KAGE intro with Get Started and Chat with Nori shortcut
- Home command center connected to assignments and recorded academic results
- Recover dashboard
- Study Center with Nori, subjects, study blocks, assessments, assignments, library, AI short notes, calculator and timer
- Tracker with result bars, graph, Merit Points and active controls
- Profile and organized Settings
- Nori chat sidebar with history/library/settings/profile/voice access
- Voice-chat prototype with mute, text-to-voice, wake/answer completion and explicit Quit Chat
- Local persistence through localStorage
- Responsive desktop/tablet/mobile layout

## Data behavior
Subject results start at 0 and only change when an assessment is recorded. Assignments created in Study are surfaced on Home and priorities. Study blocks and focus sessions contribute to tracked activity.

## AI provider direction
The UI labels Gemini as Nori's primary reasoning provider, with the application intelligence layer kept separate from provider-specific calls so the native project can connect its existing routing/fallback system later.

## Run
Open `index.html` in a modern browser or serve the folder with any static web server.

## Nori Avatar v6

The selectable **Nori Avatar** interface was upgraded without changing the rest of the KAGE app. It now uses the supplied KAGE character-sheet artwork as the source for the live avatar system:

- 9 mapped facial expressions: Neutral, Focused, Analytical, Concerned, Strict, Disappointed, Encouraging, Proud, Success, Surprised.
- 8 key poses: Default KAGE, Analysis, Execute, New Era Book, Rule Warning, Success, Recovery, Focus Mode.
- Front / side / back turnaround references are included for future native 3D/2.5D work.
- The main avatar stays centered during normal conversation with subtle breathing, sway, glow, and speech/listening motion.
- Avatar-only visual generation is available from Nori Chat. It appears only after the student asks Nori to show/generate a visual or to display student status.
- Student-status visuals use the app's recorded academic data; no unrecorded scores are invented.
- Topic visuals are generated as lightweight in-app diagrams/cards in the prototype. The native implementation can replace this renderer with the connected image-generation service.
- Other Nori interfaces (Classic, Aurora, Mark VII, Iris) keep their existing behavior and do not receive the Avatar-only visual/pose feature.
- KAGE Classic remains the default interface.

The original supplied source sheets are retained in `assets/nori/source-character-sheet.png` and `assets/nori/source-dashboard.png`.
