/* NORI STABLE IMAGE API V1 — Gemini Nano Banana first, provider-independent route. */
const {cors,requireUser,rateLimit,bodyLimit,parsedBodyLimit}=require('./_security');
const CONTRACT='nori-image-v1';
const GEMINI_MODELS=[process.env.GEMINI_IMAGE_MODEL||'gemini-3.1-flash-image',process.env.GEMINI_IMAGE_FALLBACK_MODEL||'gemini-3-pro-image'];
function promptFor(p){
  return [
    'Nori image generation task. Produce a visually precise, coherent result.',
    'Preserve requested subject count, relationships, proportions, spatial layout, colors, labels, and important constraints.',
    'Do not invent extra people, objects, text, logos, or visual elements that were not requested.',
    'If text is requested, render it exactly and legibly. Prefer clean composition and readable typography.',
    'USER REQUEST:',String(p||'').trim()
  ].join('\n');
}
async function gemini(model,prompt,format){
  const key=process.env.GEMINI_API_KEY;if(!key)throw new Error('GEMINI_API_KEY not configured');
  const r=await fetch('https://generativelanguage.googleapis.com/v1beta/interactions',{method:'POST',headers:{'x-goog-api-key':key,'Content-Type':'application/json'},body:JSON.stringify({model:model,input:prompt,response_format:{type:'image',mime_type:'image/png',aspect_ratio:format.aspect_ratio||'1:1',image_size:format.image_size||'2K'}})});
  const d=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error((d.error&&d.error.message)||('Gemini image HTTP '+r.status));
  const img=d.output_image&&d.output_image.data;if(!img)throw new Error('Image provider returned no image');
  return {b64_json:img,mime_type:d.output_image.mime_type||'image/png',provider:'gemini',model:model};
}
module.exports=async function(req,res){
  cors(req,res);res.setHeader('Access-Control-Allow-Methods','POST,OPTIONS');res.setHeader('X-Nori-Image-Contract',CONTRACT);
  if(req.method==='OPTIONS')return res.status(204).end();
  if(req.method!=='POST')return res.status(405).json({error:'POST only'});
  if(!bodyLimit(req))return res.status(413).json({error:'Request too large'});
  const user=await requireUser(req,res);if(!user)return;
  if(!(await rateLimit(req,'image.js',15,60000)))return res.status(429).json({error:'Rate limit exceeded'});
  if(!parsedBodyLimit(req.body,100000))return res.status(413).json({error:'Request too large'});
  const prompt=promptFor(req.body&&req.body.prompt);if(!prompt.trim())return res.status(400).json({error:'Image prompt required'});
  const format={aspect_ratio:String(req.body.aspect_ratio||'1:1'),image_size:String(req.body.image_size||'2K')};
  let last=null;
  for(const model of GEMINI_MODELS){try{return res.status(200).json(Object.assign({ok:true,apiContract:CONTRACT},await gemini(model,prompt,format)));}catch(e){last=e;}}
  return res.status(502).json({error:'Image generation unavailable',detail:last&&last.message||'provider failure'});
};
