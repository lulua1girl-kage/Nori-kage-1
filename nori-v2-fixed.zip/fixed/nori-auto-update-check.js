/* NORI AUTO-UPDATE CHECK
   The API gateway (api/nori.js) already reports its contract + brain version
   on every GET request via X-Nori-Brain-Version / apiContract in the JSON
   body. This module polls that on load and periodically, and shows a small
   banner when the version changes since the last time this device saw it —
   no separate manifest host required. If a real static manifest URL is later
   set via window.NORI_UPDATE_MANIFEST_URL, NoriUpdateV31.check() (loaded
   separately) can still be used for staged config/theme updates. */
(function(g){'use strict';
  var KEY='nori_seen_brain_version';
  function seen(){try{return localStorage.getItem(KEY)}catch(e){return null}}
  function remember(v){try{localStorage.setItem(KEY,v)}catch(e){}}
  function banner(newVersion){
    if(document.querySelector('.nori-update-banner'))return;
    var el=document.createElement('div');
    el.className='nori-update-banner';
    el.innerHTML='<span>Nori brain updated to v'+String(newVersion).replace(/[<>&]/g,'')+'. Refresh to use it.</span><button type="button">REFRESH</button>';
    el.querySelector('button').onclick=function(){location.reload()};
    document.body.appendChild(el);
  }
  async function check(){
    try{
      var r=await fetch('/api/nori',{method:'GET',cache:'no-store'});
      if(!r.ok)return;
      var d=await r.json();
      var v=d && (d.brainVersion||d.apiContract);
      if(!v)return;
      var last=seen();
      if(last && last!==String(v)) banner(v);
      remember(String(v));
    }catch(e){ /* offline or backend not deployed yet — fail silently, no fake status shown */ }
  }
  g.NoriAutoUpdateCheck={check:check};
  if(document.readyState==='complete')check();else window.addEventListener('load',check);
  setInterval(check,15*60*1000);
})(window);
