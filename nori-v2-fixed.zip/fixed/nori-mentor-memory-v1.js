/* NORI MENTOR MEMORY V1 — stores confirmed learning preferences/patterns separately from facts. */
(function(g){'use strict'; const KEY='nori_mentor_memory_v1';
 function read(){try{return JSON.parse(localStorage.getItem(KEY)||'{"preferences":{},"patterns":[],"commitments":[] }')}catch(_){return {preferences:{},patterns:[],commitments:[]}}}
 function write(x){try{localStorage.setItem(KEY,JSON.stringify(x))}catch(_){};return x}
 function remember(type,key,value,confidence){const x=read(); if(type==='preference')x.preferences[key]={value,confidence:confidence||'confirmed',updatedAt:new Date().toISOString()}; else {const arr=x[type]||[];arr.unshift({value,confidence:confidence||'observed',updatedAt:new Date().toISOString()});x[type]=arr.slice(0,40)} return write(x)}
 function context(){const x=read();return {preferences:x.preferences,patterns:x.patterns.slice(0,12),commitments:x.commitments.slice(0,12)}}
 g.NoriMentorMemoryV1={read,remember,context,version:1};
})(window);
