/* NORI RUNTIME ORCHESTRATOR V1 — joins the advanced layers without replacing existing UI modules. */
(function(g){'use strict';
 function context(){
  const c=g.NoriCanonicalContextV1?.cached?.()||{}; const m=g.NoriMentorMemoryV1?.context?.()||{};
  return {canonical:c,mentor:m,resilience:g.NoriResilienceV1?.status?.()||{},voice:g.NoriVoiceSessionV1?.get?.()||{},strict:g.NoriStrictRuntimeV1?.rules||{}};
 }
 async function refresh(){const c=g.NoriCanonicalContextV1; if(c?.get)try{return await c.get()}catch(_){} return context().canonical}
 async function boot(){if(g.NoriResilienceV1?.health)g.NoriResilienceV1.health(); return context()}
 function localAnswer(message){return g.NoriResilienceV1?.localFallback?.(message)||'Nori local mode is active.'}
 g.NoriRuntimeOrchestratorV1={context,refresh,boot,localAnswer,version:1};
 setTimeout(boot,2500);
})(window);
