/* Compatibility shim: V27 is the active stable visual engine. */
