# Nori V5 — Voice / Listening / Navigation

- Added native local double-clap detector.
- Added adaptive acoustic level events.
- Improved wake-word detection using partial recognition and a bounded active-listening window.
- Prefer on-device Android speech recognition when supported.
- Added longer end-of-speech thresholds and partial-result deduplication.
- Added natural "Nori, ..." command normalization.
- Added internal voice navigation for Home, Study, Recovery, Profile, Calendar and Alarms.
- Added launcher-based app resolution for voice `open/launch/start` commands.
- Added native intent-to-WebView route handoff.
- Added native voice control bridge for Meet Nori.
- Added TTS speech audio focus and maximum app-level TTS volume.
- Preserved explicit user opt-in, foreground notification and bounded background voice session.
