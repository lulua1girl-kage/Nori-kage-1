/* NORI MODERN INTEGRATION BRIDGE
 * The Modern UI is presentation only. Nori V3 remains the source of truth for
 * authentication, brain routing, native voice, KAGE rules, recovery, memory and
 * deterministic academic state.
 */
(function(){
  'use strict';
  const CFG=window.NORI_MODERN_CONFIG||{};
  const native=()=>window.Capacitor?.Plugins||{};
  async function session(){return window.NoriSyncAuth?.session?.()||{data:{session:null}};}
  async function profile(){try{return await window.NoriSyncAuth?.profile?.()||null}catch(_){return null}}
  async function signOut(){
    try{ await window.NoriSyncAuth?.signOut?.(); }catch(_){ }
    try{ await native().NoriAuth?.signOut?.(); }catch(_){ }
    window.NoriAuthGate?.refresh?.();
    document.dispatchEvent(new CustomEvent('nori:modern-signed-out'));
  }
  async function askNori(message, context){
    // V2 FIX: this used to hard-fail on no session, then fetch a Supabase Edge
    // Function URL (functions/v1/nori-brain) that is not part of this project at
    // all — it was never deployed, so every real chat request 404'd and the
    // caller silently swapped in a fake canned reply. The actual multi-provider
    // brain (Gemini -> OpenAI -> OpenAI backup -> Groq fallback chain) lives at
    // api/brain.js and is served at /api/nori. NoriApiV1 already targets that
    // endpoint correctly and already attaches the Supabase auth token when one
    // exists, so route through it instead of a one-off fetch.
    const unified=window.NoriUnifiedState?.snapshot?.()||null;
    const mergedContext=Object.assign({},context||{},{canonicalState:unified,source:'nori-modern'});
    if(!window.NoriApiV1) throw new Error('NORI_API_CLIENT_UNAVAILABLE');
    return window.NoriApiV1.request({message,context:mergedContext});
  }
  function state(){
    return {user:window.NoriSyncAuth?.user?.()||null,profile:window.NoriProfile||null,native:!!window.NORI_IS_NATIVE,unified:window.NoriUnifiedState?.snapshot?.()||null};
  }
  window.NoriModernBridge={session,profile,signOut,askNori,state};
  window.addEventListener('nori:auth-ready',()=>document.dispatchEvent(new CustomEvent('nori:modern-auth-ready')));
})();
